### Simple HTML5 Drawing App with Paint Bucket Tool

Original article on Paint Bucket Tool: http://wmalone.com/bucket
Original article on Simple Drawing App at: http://wmalone.com/draw

![My Image](http://www.williammalone.com/projects/html5-canvas-javascript-drawing-app-with-bucket-tool/images/example.png)